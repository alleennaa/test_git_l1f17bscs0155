package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    SQLiteHelper myDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity);
        myDatabase = new SQLiteHelper(this);
    }
    public void sendtotwo(View view)
    {
        Intent i=new Intent (this, Activity2.class);
        startActivity(i);
    }
    public void sendtothree(View view)
    {
        Intent i=new Intent (this, activity3.class);
        startActivity(i);
    }
}
