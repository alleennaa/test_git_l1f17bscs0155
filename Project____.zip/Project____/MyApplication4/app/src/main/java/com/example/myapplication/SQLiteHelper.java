package com.example.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteHelper  extends SQLiteOpenHelper {


    public static final String databaseName = "dawai.db";
    public static final String tableName = "Medicine";
    public static final String Col1 = "Sr_no";
    public static final String Col2 = "Name";
    public static final String Col3 = "Dosage";
    public static final String Col4 = "Disease";
    public static final String Col5 = "Price";


    public SQLiteHelper(Context context) {
        super(context, databaseName, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();//SqlLite handler 'db'.two options readable & writeable,Difference is when allocating memory and is not important.other wise it is same
    }

    String SQlString = "create table " + tableName +
            "("
            + Col1 + " Integer Primary Key Autoincrement, "
            + Col2 + " Text, "
            + Col3 + " Text, "
            + Col4 + " Text, "
            + Col5 + " Text" +
            ")";


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQlString);

        db.execSQL("INSERT INTO " + tableName + "(Name, Dosage, Disease, Price ) VALUES ('Brufen', '3', 'Fever', 'Rs.20')");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + tableName);//drop table means delete and if exists means if it is not null.
        onCreate(db);

    }
}
