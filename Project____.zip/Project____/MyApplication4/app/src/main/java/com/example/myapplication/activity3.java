package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class activity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity3);
    }
    public void sendtosix(View view)
    {
        Intent i=new Intent (this, activity6.class);
        startActivity(i);
    }
    public void sendtoseven(View view)
    {
        Intent i=new Intent (this, Activity7.class);
        startActivity(i);
    }
}
